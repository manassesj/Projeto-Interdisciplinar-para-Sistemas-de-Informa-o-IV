--AWS Real-time analytics

--Create state with Fº and likelihood .

